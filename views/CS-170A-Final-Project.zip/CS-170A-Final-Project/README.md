# CS-170A-Project

This project analyzes hypothetical tennis matchups using data collected from 1991 to 2016. 
