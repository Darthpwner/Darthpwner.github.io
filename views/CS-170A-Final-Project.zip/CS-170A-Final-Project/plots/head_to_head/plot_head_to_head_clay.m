% Head to Head Clay
plot(head_to_head_clay, '*', 'MarkerSize',12);
title('Head to Head Clay')
xlabel('Players');
ylabel('Winning Percentage');
legend('Becker', 'Edberg', 'Courier', 'Sampras', 'Agassi', 'Muster', 'Rios', 'Moya', 'Kafelnikov', 'Rafter', 'Safin', 'Kuerten', 'Hewitt', 'Ferrero', 'Roddick', 'Federer', 'Nadal', 'Djokovic', 'Murray');
