covariance_all_to_grass = cov(head_to_head_all, head_to_head_grass)

bar(covariance_all_to_grass);
