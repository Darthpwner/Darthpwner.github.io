covariance_all_to_hard = cov(head_to_head_all, head_to_head_hard)

bar(covariance_all_to_hard);
