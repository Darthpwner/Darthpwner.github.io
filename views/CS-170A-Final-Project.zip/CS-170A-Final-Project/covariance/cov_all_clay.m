covariance_all_to_clay = cov(head_to_head_all, head_to_head_clay)

bar(covariance_all_to_clay);
