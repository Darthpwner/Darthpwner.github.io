[n, d] = knnsearch(head_to_head_hard, percentage_of_deciding_sets_won_hard, 'k', 19)
gscatter(n, d);
