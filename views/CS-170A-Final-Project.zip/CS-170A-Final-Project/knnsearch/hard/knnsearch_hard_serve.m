[n, d] = knnsearch(head_to_head_hard, percentage_of_service_games_won_hard, 'k', 19)
gscatter(n, d);
