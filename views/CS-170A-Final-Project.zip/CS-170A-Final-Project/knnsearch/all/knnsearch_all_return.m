[n, d] = knnsearch(head_to_head_all, percentage_of_return_games_won_all, 'k', 19)
gscatter(n, d);
