[n, d] = knnsearch(head_to_head_grass, percentage_of_service_games_won_grass, 'k', 19)
gscatter(n, d);
