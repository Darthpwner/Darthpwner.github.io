[n, d] = knnsearch(head_to_head_clay, percentage_of_tiebreaks_won_clay, 'k', 19)
gscatter(n, d);
